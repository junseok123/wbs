from django.shortcuts import render
from .models import WBSItem

def wbs_list_view(request):
    items = WBSItem.objects.all().order_by('id')
    return render(request, 'wbs_input_home.html', {'items': items})
